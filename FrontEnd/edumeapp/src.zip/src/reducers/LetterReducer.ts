import { LettersDispatchTypes, LETTERS_FAIL, LETTERS_LOADING, LETTERS_SUCCESS } from "../actions/LettersActionType";

export interface LettersState {
    loading: boolean;
    payload?: string
}

const initialState: LettersState = {

   loading: false
}

const lettersReducer = (state: LettersState = initialState,
    action: LettersDispatchTypes) : LettersState => {
    
        switch(action.type){

            case LETTERS_FAIL :
                return {                  
                    loading: false
                }
            case LETTERS_LOADING : 
            return {
                loading: true
            }
            case LETTERS_SUCCESS : 
            return {
                loading: false,
                payload: action.payload
            }
            
        }
    }
    

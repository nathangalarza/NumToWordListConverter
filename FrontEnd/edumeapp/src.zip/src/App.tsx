import React from 'react';
// import logo from './logo.svg';
import { Counter } from './features/counter/Counter';
import { Convert } from './features/convert/ConvertNumToList';

import './App.scss';
import { WordsTable } from './features/wordStable/WordStable';

function App() {
  return (
    <div className="App">
      <header className="App-header">
     
        {/* <Counter /> */}
        <Convert/>
        <WordsTable/>
   
      </header>
    </div>
  );
}

export default App;

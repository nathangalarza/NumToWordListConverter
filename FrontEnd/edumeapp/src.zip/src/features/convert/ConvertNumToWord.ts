//This file contains the logic for calling the api for every Key press.
import { RootState, AppThunk } from '../../app/store';
import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit';

// export const getQueryAsync = createQueryAsync(


// );
import { spawn } from 'child_process';

import React, { useState } from 'react';

import { useAppSelector, useAppDispatch } from '../../app/hooks';
import { selectNumber } from '../convert/numberSlice';

import { addWord, selectWordList } from './wordListSlice';




export function WordsTable(){
    // const number = useAppSelector(selectNumber);
    // const number = useAppSelector(selectNumber);
    // const dispatch = useAppDispatch();
    // const dispatch = useAppDispatch();

    return(
      
        <div>
          <h4>History</h4>
           <table>
  <tr>
    <th>Combinations</th>
  </tr>
  <tr>
    <td>Alfreds Futterkiste</td>
  </tr>
</table> 
        </div>
    );
}
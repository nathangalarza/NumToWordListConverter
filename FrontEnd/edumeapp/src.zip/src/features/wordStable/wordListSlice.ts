import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit';
import { stat } from 'fs';
import { useAppSelector } from '../../app/hooks';
import { RootState, AppThunk } from '../../app/store';
import conversionService from '../../services/conversion.service';
import { selectNumber } from '../convert/numberSlice';


export interface wordListState {
    list: [];
    length: number
}

const initialState: wordListState = {
    list: [],
    length: 0
  };

  export const wordListSlice = createSlice({
    name: 'wordList',
    initialState,
    reducers: {
      addWord : (state, key) => {

        // Redux Toolkit allows us to write "mutating" logic in reducers. It
        // doesn't actually mutate the state because it uses the Immer library,
        // which detects changes to a "draft state" and produces a brand new
        // immutable state based off those changes
        // state.isEmpty = false;
        // state.value += key.payload;
        // state.length = state.value.length;
        // getConversion(state.value);
        //state.list.push(response.payload);

      }
    }
  }
  );
  export const getWordsAsync = createAsyncThunk(
    'convert',
    async (amount: string) => {
      debugger;
    //  const number = useAppSelector(selectNumber);
      const response = await fetchCount(amount);
      // The value we return becomes the `fulfilled` action payload
      return response.data;
    }
  );
  
  export function fetchCount(value : string){
    return new Promise<{ data: string }>(() =>
    conversionService.get(value)
     .then((response: any) =>{
        console.log(JSON.stringify(response.data));
       return response.data}))
  }

  export const { addWord } = wordListSlice.actions;

  export const selectWordList = (state: RootState) => state.wordList.list;

  export default wordListSlice.reducer;